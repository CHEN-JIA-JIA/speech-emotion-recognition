import sys
import os
import numpy as np
import torch
import torch.nn.functional as F
from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QPushButton, QVBoxLayout, QWidget, QMessageBox, QHBoxLayout, QGridLayout, QTableWidget, QTableWidgetItem)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon, QPixmap, QFont
import pyaudio
from transformers import Wav2Vec2Model, Wav2Vec2Config
from datetime import datetime

# 情绪标签
EMOTION_LABELS = [
    "neutral", "calm", "happy", "sad", "angry", "fearful", "disgust", "surprised"
]

# PyTorch 模型定义
class LocalAttention(torch.nn.Module):
    def __init__(self, hidden_dim, attn_window=5):
        super(LocalAttention, self).__init__()
        self.hidden_dim = hidden_dim
        self.attn_window = attn_window
        self.attn_score = torch.nn.Linear(hidden_dim, 1)

    def forward(self, rnn_output):
        bsz, seq_len, dim = rnn_output.shape
        outputs = []
        for t in range(seq_len):
            start = max(0, t - self.attn_window)
            end = min(seq_len, t + self.attn_window + 1)
            local_context = rnn_output[:, start:end, :]
            scores = self.attn_score(local_context)
            alpha = F.softmax(scores, dim=1)
            weighted_sum = (local_context * alpha).sum(dim=1)
            outputs.append(weighted_sum.unsqueeze(1))
        return torch.cat(outputs, dim=1)

class EmotionModel(torch.nn.Module):
    def __init__(self, num_emotions=8, hidden_size=128, attn_window=5, feature_dim=768):
        super(EmotionModel, self).__init__()
        self.lstm = torch.nn.LSTM(
            input_size=feature_dim,
            hidden_size=hidden_size,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        self.local_attn = LocalAttention(hidden_size*2, attn_window=attn_window)
        self.classifier = torch.nn.Sequential(
            torch.nn.Linear(hidden_size*2, hidden_size),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_size, num_emotions)
        )

    def forward(self, features):
        lstm_out, _ = self.lstm(features)
        attn_out = self.local_attn(lstm_out)
        pooled = attn_out.mean(dim=1)
        logits = self.classifier(pooled)
        return logits

# 实时推理函数
def real_time_inference(audio_chunk, wav2vec_model, emotion_model, device):
    if device is None:
        device = torch.device("cpu")
    if audio_chunk.dim() == 1:
        audio_chunk = audio_chunk.unsqueeze(0)  # => [1, time]
    audio_chunk = audio_chunk.to(device)

    with torch.no_grad():
        out = wav2vec_model(audio_chunk)
        hidden_states = out.last_hidden_state
        logits = emotion_model(hidden_states)
        pred_idx = torch.argmax(logits, dim=1).item()

    return pred_idx

# PyQt GUI 类
class SpeechEmotionApp(QMainWindow):
    def __init__(self, wav2vec_model, emotion_model, device):
        super().__init__()

        self.wav2vec_model = wav2vec_model
        self.emotion_model = emotion_model
        self.device = device

        self.sample_rate = 16000
        self.channels = 1
        self.record_seconds = 2
        self.chunk = 1024
        self.format = pyaudio.paInt16

        self.history = []  # 用于存储历史记录

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Real-Time Speech Emotion Recognition")
        self.setGeometry(100, 100, 2400, 1500)
        self.setWindowIcon(QIcon("icon.png"))  # 设置窗口图标

        main_layout = QVBoxLayout()

        # 添加背景图片
        background_label = QLabel()
        background_label.setPixmap(QPixmap("background.png"))
        background_label.setScaledContents(True)
        background_label.setStyleSheet("border: 1px solid #000;")
        main_layout.addWidget(background_label, stretch=1)

        # 标签部分
        self.label = QLabel("Click the button to record and recognize emotions")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 46px; font-weight: bold; color: #555; padding: 30px;")
        main_layout.addWidget(self.label)

        # 按钮部分
        button_layout = QGridLayout()

        self.record_button = QPushButton("Start Recording")
        # self.record_button.setIcon(QIcon("record_icon.png"))
        self.record_button.setStyleSheet("font-size: 36px; padding: 20px; background-color: #4CAF50; color: black; border-radius: 8px;")
        self.record_button.clicked.connect(self.record_audio)
        button_layout.addWidget(self.record_button, 0, 0)

        self.history_button = QPushButton("History")
        self.history_button.setIcon(QIcon("history_icon.png"))
        self.history_button.setStyleSheet("font-size: 36px; padding: 20px; background-color: #FFC107; color: black; border-radius: 8px;")
        self.history_button.clicked.connect(self.show_history)
        button_layout.addWidget(self.history_button, 0, 1)

        self.quit_button = QPushButton("Exit")
        # self.quit_button.setIcon(QIcon("exit_icon.png"))
        self.quit_button.setStyleSheet("font-size: 36px; padding: 20px; background-color: #f44336; color: black; border-radius: 8px;")
        self.quit_button.clicked.connect(self.close)
        button_layout.addWidget(self.quit_button, 0, 2)

        main_layout.addLayout(button_layout)

        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

    def record_audio(self):
        self.label.setText("Recording... Please wait")
        self.label.setStyleSheet("font-size: 46px; font-weight: bold; color: #FF5722;")
        QApplication.processEvents()

        audio_data = self.capture_audio()
        waveform = torch.from_numpy(audio_data).float()

        pred_idx = real_time_inference(
            audio_chunk=waveform,
            wav2vec_model=self.wav2vec_model,
            emotion_model=self.emotion_model,
            device=self.device
        )

        pred_emotion = EMOTION_LABELS[pred_idx] if 0 <= pred_idx < len(EMOTION_LABELS) else f"Unknown({pred_idx})"

        # 保存历史记录
        timestamp = datetime.now().strftime("%b %d, %Y %H:%M:%S")
        self.history.append((timestamp, pred_emotion))

        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Recognition Result")
        msg_box.setWindowIcon(QIcon("icon.png"))  # 设置左上角图标
        msg_box.setText(f"<b>Predicted Emotion:</b> <i>{pred_emotion}</i>")
        msg_box.setStyleSheet("font-size: 40px;")
        msg_box.setFixedSize(1600, 1000)
        msg_box.setIconPixmap(QIcon("result_icon.png").pixmap(120, 120))
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec_()

        self.label.setText("Click the button to record and recognize emotions")
        self.label.setStyleSheet("font-size: 46px; font-weight: bold; color: #555;")

    def capture_audio(self):
        pa = pyaudio.PyAudio()
        stream = pa.open(
            format=self.format,
            channels=self.channels,
            rate=self.sample_rate,
            input=True,
            frames_per_buffer=self.chunk
        )

        frames = []
        num_frames = int(self.sample_rate / self.chunk * self.record_seconds)

        for _ in range(num_frames):
            data = stream.read(self.chunk)
            frames.append(data)

        stream.stop_stream()
        stream.close()
        pa.terminate()

        audio_bytes = b''.join(frames)
        audio_array = np.frombuffer(audio_bytes, dtype=np.int16)
        audio_array = audio_array.astype(np.float32) / 32767.0
        return audio_array

    def show_history(self):
        history_window = QMainWindow(self)
        history_window.setWindowTitle("History")

        # 获取屏幕分辨率，计算窗口居中位置
        screen = QApplication.primaryScreen().availableGeometry()
        screen_width, screen_height = screen.width(), screen.height()
        window_width, window_height = 800, 600
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        history_window.setGeometry(x, y, window_width, window_height)

        # 创建表格部件
        table_widget = QTableWidget()
        table_widget.setRowCount(len(self.history))
        table_widget.setColumnCount(2)
        table_widget.setHorizontalHeaderLabels(["Timestamp", "Predicted Emotion"])

        # 设置字体大小为 16px
        font = QFont()
        font.setPointSize(10)
        table_widget.setFont(font)

        # 填充表格数据
        for row, (timestamp, emotion) in enumerate(self.history):
            table_widget.setItem(row, 0, QTableWidgetItem(timestamp))
            table_widget.setItem(row, 1, QTableWidgetItem(emotion))

        # 设置列宽为固定值
        table_widget.setColumnWidth(0, 400)  # 第一列宽度
        table_widget.setColumnWidth(1, 300)  # 第二列宽度

        # 表格铺满窗口
        table_widget.horizontalHeader().setStretchLastSection(True)
        table_widget.verticalHeader().setDefaultSectionSize(50)  # 设置行高
        table_widget.setSizeAdjustPolicy(QTableWidget.AdjustToContents)

        # 将表格设置为窗口中央部件
        history_window.setCentralWidget(table_widget)
        history_window.show()

# 主函数
def main():
    best_model_path = r"./best1.pth"
    if not os.path.exists(best_model_path):
        print(f"Model file {best_model_path} not found. Please check the path.")
        sys.exit(1)

    checkpoint = torch.load(best_model_path, map_location="cpu")
    print(f"Loaded checkpoint from {best_model_path}")

    config = Wav2Vec2Config.from_pretrained("facebook/wav2vec2-base-960h")
    wav2vec_model = Wav2Vec2Model.from_pretrained("facebook/wav2vec2-base-960h", config=config)
    wav2vec_model.load_state_dict(checkpoint["wav2vec_model_state"], strict=False)

    emotion_model = EmotionModel(
        num_emotions=8,
        hidden_size=128,
        attn_window=5,
        feature_dim=768
    )
    emotion_model.load_state_dict(checkpoint["emotion_model_state"])

    device = torch.device("cpu")
    wav2vec_model.to(device)
    emotion_model.to(device)
    wav2vec_model.eval()
    emotion_model.eval()

    app = QApplication(sys.argv)
    window = SpeechEmotionApp(wav2vec_model, emotion_model, device)
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
